#ifndef _REGISTERPROTOCOL_H
#define _REGISTERPROTOCOL_H

void RegisterProtocols();
void UnregisterProtocols();

#endif	//_REGISTERPROTOCOL_H